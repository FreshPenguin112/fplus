from lexer import lexer
from parser import parser

print(parser.parse(lexer.lex('echo(0.5 + 9 - .1 * 25 / 2)')))